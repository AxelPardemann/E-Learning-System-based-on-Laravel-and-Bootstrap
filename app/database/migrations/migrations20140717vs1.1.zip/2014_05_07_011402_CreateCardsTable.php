<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCardsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('cards', function(Blueprint $table)
		{
			$table->engine = 'InnoDB';
			$table->increments('id');
			$table->integer('sprint')->unsigned();
			$table->string('name');
			$table->text('description');
			$table->string('card_type', 20);

			$table->string('f_text');
            $table->string('f_sound');
			$table->string('f_sound_path');
            $table->string('f_image');
			$table->string('f_image_path');

			$table->string('b_text');
            $table->string('b_sound');
			$table->string('b_sound_path');
            $table->string('b_image');
			$table->string('b_image_path');
			
			$table->datetime('created_at');
			$table->datetime('updated_at');
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('cards');
	}

}
